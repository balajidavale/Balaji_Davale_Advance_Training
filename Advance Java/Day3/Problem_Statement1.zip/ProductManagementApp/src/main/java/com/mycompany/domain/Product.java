package com.mycompany.domain;

public class Product {
	int product_id;
    String product_Name;
    int product_Price;
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getProduct_Name() {
		return product_Name;
	}
	public void setProduct_Name(String product_Name) {
		this.product_Name = product_Name;
	}
	public int getProductPrice() {
		return product_Price;
	}
	public void setProductPrice(int productPrice) {
		this.product_Price = productPrice;
	}
	public Product(int product_id, String product_Name, int productPrice) {
		super();
		this.product_id = product_id;
		this.product_Name = product_Name;
		this.product_Price = productPrice;
	}
	@Override
	public String toString() {
		return "Product [product_id=" + product_id + ", product_Name=" + product_Name + ", product_Price=" + product_Price
				+ "]";
	}

}
