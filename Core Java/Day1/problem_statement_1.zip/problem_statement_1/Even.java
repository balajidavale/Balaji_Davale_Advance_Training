package com;

import java.util.Scanner;

public class Even {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int n=0,i=0;

         

	       Scanner b = new Scanner(System.in);

	         

	       System.out.print("Enter value n : ");

	       n = b.nextInt();

	         

	       for(i=1; i<n; i++)

	       {

	           if(i%2==0)

	               System.out.print(i+" ");

	       }    

	      

	         

	   }

	
	}

