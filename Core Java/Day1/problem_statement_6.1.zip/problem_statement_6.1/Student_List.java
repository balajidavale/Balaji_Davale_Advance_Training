package com;

import java.util.ArrayList;

public class Student_List {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

ArrayList<Integer> list = new ArrayList<>();

		
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		list.add(8);
			
		
		if(list.indexOf(2)>=0)
			System.out.println("2 Balaji exists in the ArrayList");
			
		else
			System.out.println("2 Dhoni does not exist in the ArrayList");
			
		if(list.indexOf(8)>=0)
			System.out.println("8 Nikhil exists in the ArrayList");
			
		else
			System.out.println("8 viru not exist in the ArrayList");
			
		}
	}

